package com.example.quinch;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

public class finish extends AppCompatActivity {
    public TextView textView1, textView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finish);
        Intent intent=getIntent();
        String mark=intent.getStringExtra("point1");
        TextView points=findViewById(R.id.textView5);
        points.setText(mark);

        TextView textView1=findViewById(R.id.textView4);
        TextView textView2=findViewById(R.id.textView5);
        //Animation zoom= AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom);
        //textView1.startAnimation(zoom);
        //textView2.startAnimation(zoom);
    }
}
